export const BRAND = {
  name: "Lighterracy",
  orange: "#FDA50F",
  navy: "#0e2a47",
};

export const COPY = {
  tagline: "the more you read, the brighter your spirit",
  heroCtaScan: "Scan ISBN",
  heroCtaPromo: "Cari Promo",
  sourceGoogle: "Google Books",
  sourceDB: "Lighterracy DB",
  sourceNYT: "New York Times",
};
