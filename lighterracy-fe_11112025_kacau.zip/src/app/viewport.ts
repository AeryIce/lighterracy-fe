import type { Viewport } from "next";

export const viewport: Viewport = {
  themeColor: "#ffffff", // sesuaikan brand kalau perlu
};
