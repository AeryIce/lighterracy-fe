"use client";

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

type Book = {
  title: string;
  subtitle?: string;
  authors: string[];
  publisher: string;
  publishedDate: string;
  description: string;
  cover: string | null;
  pageCount: number | null;
  dimensions: { height?: string; width?: string; thickness?: string } | null;
  categories: string[];
  averageRating: number | null;
  ratingsCount: number | null;
};

type Props = { open: boolean; book: Book | null; onOpenChange?: (v: boolean) => void };

export default function BookDetailModal({ open, onOpenChange, book }: Props) {
  if (!open) return null;

  return (
    <Dialog open={open} onOpenChange={(v) => onOpenChange?.(v)}>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>{book?.title || "Tidak ditemukan"}</DialogTitle>
        </DialogHeader>

        {book && (
          <div className="grid grid-cols-1 md:grid-cols-[220px,1fr] gap-4 md:gap-6">
            <div className="w-[220px] h-[320px] md:w-[240px] md:h-[360px] rounded-xl overflow-hidden bg-neutral-100">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={book.cover || "/og/og-from-upload.png"}
                alt={book.title}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="text-sm leading-relaxed">
              {book.authors.length ? (
                <div className="text-[13px] text-muted-foreground">
                  <span className="opacity-70">Penulis:</span> <b>{book.authors.join(", ")}</b>
                </div>
              ) : null}

              {(book.publisher || book.publishedDate) && (
                <div className="text-[13px] text-muted-foreground mt-1">
                  <span className="opacity-70">Publikasi:</span>{" "}
                  {[book.publisher, book.publishedDate].filter(Boolean).join(" · ")}
                </div>
              )}

              {(book.pageCount || book.dimensions) && (
                <div className="text-[13px] text-muted-foreground mt-1 flex flex-wrap gap-x-6 gap-y-1">
                  {book.pageCount ? <span><span className="opacity-70">Halaman:</span> {book.pageCount}</span> : null}
                  {book.dimensions ? (
                    <span>
                      <span className="opacity-70">Dimensi:</span>{" "}
                      {[book.dimensions?.height, book.dimensions?.width, book.dimensions?.thickness].filter(Boolean).join(" × ")}
                    </span>
                  ) : null}
                </div>
              )}

              {book.categories.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {book.categories.map((c, i) => (
                    <span key={i} className="text-xs px-2 py-1 rounded-full bg-black/5">{c}</span>
                  ))}
                </div>
              )}

              <p className="mt-3 text-sm">
                {book.description || "(Tidak ada deskripsi dari Google Books.)"}
              </p>

              <div className="mt-4">
                <button
                  onClick={() => onOpenChange?.(false)}
                  className="px-3 py-2 rounded-lg bg-neutral-200 text-sm"
                >
                  Tutup
                </button>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
