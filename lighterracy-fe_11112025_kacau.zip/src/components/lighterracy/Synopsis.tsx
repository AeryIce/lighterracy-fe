export default function Synopsis({ text }: { text: string }) {
  return <p className="text-sm text-muted-foreground leading-relaxed">{text}</p>;
}
