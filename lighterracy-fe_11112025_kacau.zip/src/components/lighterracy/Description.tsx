export default function Description({ text }: { text: string }) {
  return <p className="text-base text-foreground leading-relaxed">{text}</p>;
}
